import React from "react";
import style from "./index.module.css";

interface ValueTextPair {
    value: string;
    text: string
}

interface ActiveListProps {
    data: ValueTextPair[];
    value?: string
}

const ActiveList: React.FunctionComponent<ActiveListProps> = ({ data, value }) => {

    if (!data) {
        return null;
    }

    if (data.length === 0) {
        return null
    }

    let hasSelection = false;
    const items = data.map((item)=> {
        const isActive = item.value === value;
        hasSelection = isActive || hasSelection;
    return <li className={`collection-item ${style.item} ${isActive ? style.active : ''}`}>
            <div>
                <span className={`secondary-content ${style.flag}`}>
                    <i className="material-icons">check</i>
                </span>
                {item.text}
            </div>
        </li>
    })

    return <ul className={`collection ${style.root} ${hasSelection ? '' : style.noselection}`}>
        {items}
    </ul>
}

export default ActiveList;